<?php
    require("./includes/config.php");
    
    // redirects to home page
    render("home.php");
?>