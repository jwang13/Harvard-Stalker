<div class = "form-style-5">
<form action="add.php" method="post">
    <legend>Input your celebrity</legend>
    <fieldset>
       <form class="pure-form pure-form-aligned">
        <div class="pure-control-group">
            <label for="name">Celebrity Name</label>
            <input autocomplete="off" name="name" placeholder="Celebrity name" type="text"/>
        </div>
        <div class="pure-control-group">
            <button type="submit" class="btn">Add</button>
        </div>
    </fieldset>
</div>
</form>
