<!DOCTYPE html>
<html lang="en">
<head>
    
    <!-- app's own CSS -->
    <link href="/css/styles.css" rel="stylesheet"/>
    <link href = "/css/forms.css" rel = "stylesheet"/>
    <meta charset="UTF-8">
    <title>Harvard Stalker</title>
    <header>
        <h1 style="margin-top:-15px; margin-bottom:-15px">
            <p style = "color: white";>
                <img style="float: left; margin: -10px 15px 15px 0px;" src="Images/TLogo1.png" width="100" />
                Harvard Stalker, a CS50 Final Project
                <br style="clear: both;" />
            </p>
        </h1>
    </header>
</head>