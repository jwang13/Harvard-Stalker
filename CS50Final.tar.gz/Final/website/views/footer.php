<div style="text-align:center">
<h3> Thank you for visiting our website! </h3>
</div>
    <a href = index.php> <p style="text-align:center">Take me to the homepage </a>
</html>
