<!-- sends user response to verify.php -->
<div class="form-style-5">
<form action="verify.php" method="post">
    <fieldset>
        <form class="form-style-5">
          <div>
            <label for="name">Select Celebrity</label>
            <select name="celebrity">
                <option value=''></option>
                <?php
                    // prints each celebrity spotted as an option value
                    foreach($celebs as $celeb)
                    {
                        print("<option value = '{$celeb['name']}'>{$celeb['name']}</option>");
                    }
                ?>
            </select>
            <br>
            <!-- checkboxes for denial or confirmation of sighting -->
            <div>
            <label for="name">Confirmation</label>
            <input type = "checkbox" name = "response" value ="confirm"> I confirm the sighting
            <br>
            <input type = "checkbox" name = "response" value = "deny"> I deny the sighting
            </div>
        </div>
        <!-- submit button -->
         <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Submit
            </button>
    </fieldset>
</form>
</div>

