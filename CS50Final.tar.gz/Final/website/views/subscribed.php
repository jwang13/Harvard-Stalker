<!-- notifies user of registration -->
<h1> You have been registered</h1>
<h2> You will receive notifications in the future! </h2>