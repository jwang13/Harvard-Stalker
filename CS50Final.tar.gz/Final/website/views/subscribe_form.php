<div class="form-style-5">
<form action="subscribe.php" method="post">
    <fieldset>
        <!--<form class="pure-form pure-form-aligned">-->
        <form class="form-style-5">
        <!--<div class="pure-control-group">-->
        <div>
            <label for="name">Phone Number (nonhyphenated)</label>
            <input autocomplete="off" name="phone" placeholder="Phone Number" type="text"/>
        </div>
        <div>
            <label for="name">Select Carrier</label>
            <select name="carrier">
                <option value=''></option>
                <option value = att>AT&T</option>
                <option value = verizon>VERIZON</option>
                <option value = sprint>SPRINT</option>
                <option value = tmobile>TMOBILE</option>
                <option value = vmobile>VIRGIN MOBILE</option>
            </select>
        </div>
        <div>
            <label for="name">Password</label>
            <input autocomplete="off" name="password" placeholder="Password (in case you wish to unsubscribe)" type="pword"/>
        </div>
        <div>
            <label for="name">Subscribe</label>
            <button type="submit" class="btn">Subscribe</button>
        </div>
    </fieldset>
</form>
</div>
