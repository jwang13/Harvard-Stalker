<body>
        <!--<img src="Images/TLogo1.png" />-->
        <!--<h1>https://twitter.com/harvardstalker</h1>-->
        <p style="text-align:center; margin-left:23px;margin-right:23px; margin-top:-65px; width:90%; ">
            We are using the Twitter API in order to parse data from local geotagged tweets to determine if celebrities have been sighted on campus or in the area, 
            and alert our users. This process poses various intriguing natural language processing (NLP) challenges, and involves technologies
            such as SQL, PHP, HTML/CSS, Python, Bash and Javascript. 
        </p>
    <section id="main">
        <div style="text-alight:center">
        <img style="float:center; alight:center; margin-top:15px ; width:90%; " src="Images/TheYard.jpg"  />
        </div>
        
        <div>
            <a href = "subscribe.php">Subscribe</a>
        </div>
        <div>
            or <a href = "unsubscribe.php">Unsubscribe</a>
        </div>
            or <a href = "verify.php">Confirm a sighting</a>
        <div>
            or <a href = "add.php">Add a a celebrity to our database</a>
        </div>
    </section>
</body>