<!-- sends user input to unsubscripe.php -->
<div class="form-style-5">
<form action="unsubscribe.php" method="post">
    <fieldset>
        <!-- space for user's phonenumber -->
        <form class="form-style-5">
        <div>
            <label for="name">Phone Number (nonhyphenated)</label>
            <input autocomplete="off" name="phone" placeholder="Phone number (nonhyphenated)" type="text"/>
        </div>
        <!-- space for user's password -->
        <div>
            <label for="name">Password</label>
            <input autocomplete="off" name="password" placeholder="Password" type="pword"/>
        </div>
        <!-- submit button -->
        <div>
            <label for="name">Unsubscribe</label>
            <button type="submit" class="btn">Unsubscribe</button>
        </div>
    </fieldset>
</form>
</div>

 