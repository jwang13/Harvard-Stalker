<?php
     // configuration
    require("./includes/config.php");
    
    // checks if user reached page with GET
    if($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // renders subscription form if so
        render("subscribe_form.php");
    }
    
    // checks if user reached page with POST
    else if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // sanitizes user input and apologizes in case of error
        if(empty($_POST["phone"]))
        {
            say("You must input a phone number", "Aw man,");
        }
        else if(!is_numeric($_POST["phone"]))
        {
            say("Phone number incorrectly formatted", "No hyphens!");
        }
        else if(strlen($_POST["phone"]) != 10)
        {
            say("You must input area code and 7-digit phone number", "Don't blow us off");
        }
        else if(empty($_POST["carrier"]))
        {
            say("You must provide a carrier", "Sorry!");
        }
        else if(empty($_POST["password"]))
        {
            say("You must provide a password", "Our condolences!");
        }
        else
        {
            // attempts to input new user into the database
            $rows = CS50::query("INSERT IGNORE INTO subscribers (phonenumber, carrier, password) VALUES (?, ?, ?)", $_POST["phone"], $_POST["carrier"], password_hash($_POST["password"], PASSWORD_DEFAULT));
            
            // checks if entry is redundant
            if($rows == 0)
            {
                say("Phone number already subscribed", "No need to re-register!");
            }
            else
            {
                // congratulates user on subscription
                say("You have been subscribed", "Congratulations");
            }
        }
    }
?>
