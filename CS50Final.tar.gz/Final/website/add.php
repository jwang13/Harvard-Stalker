<?php 
    require("./includes/config.php");
    if($_SERVER["REQUEST_METHOD"] == "GET")
    {
        render("add_form.php");
    }
    else if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(preg_match('~[0-9]~', $_POST["name"]))
        {
            say("numbers are not celebrities", "No offense, but");
        }
        $add = CS50::query("INSERT IGNORE INTO celebs (name, spotted, confirmed) VALUES(?, 0, 0)", $_POST["name"]);
        if($add)
        {
            say("Your celebrity has been placed in our database", "Dear user,");
        }
        else
        {
            say("This celebrity is already in our database", "Silly you,");
        }
    }
?>