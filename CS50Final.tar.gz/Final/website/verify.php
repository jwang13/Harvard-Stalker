<?php
    require("./includes/config.php");
    
    // checks if user reached page via GET
    if($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // selects all celebrities spotted but not confirmed
        $celebs = CS50::query("SELECT * FROM celebs WHERE spotted AND NOT confirmed");
        
        // apologizes if no celebrities has been spotted
        if(empty($celebs))
        {
            say("No celebrities have been spotted!", "Today's a lame day");
        }
        else
        {
            // otherwise renders form of celebrities
            render("verify_form.php", ["celebs" => $celebs]);
        }
    }
    
    // checks if user has reached pase via POST
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // sanitizes user input
        if(empty($_POST["response"]))
        {
            say("You must confirm or deny the spotting", "TLI (the opposite of TMI)");
        }
        else if(empty($_POST["celebrity"]))
        {
            say("You must choose a celebrity", "Silly you!");
        }
        // sees if user has confirmed the sighting
        else if ($_POST["response"] == "confirm")
        {
            // notifies users of the confirmation of sighting
            notify("The sighting of {$_POST['celebrity']} has been confirmed");
            
            // sets confirmation boolean to true
            CS50::query("UPDATE celebs SET confirmed = 1 WHERE name = ?", $_POST['celebrity']);
        }
        // otherwise user must have denied the sighting
        else
        {
            // notifies users of the denial
            notify("The sighting of {$_POST['celebrity']} has been denied");
            
            // sets spotted boolean to false
            CS50::query("UPDATE celebs SET spotted = 0 WHERE name = ?", $_POST['celebrity']);
        }
        // thanks user
        say("Thank you for your input", "Most esteemed user,");
    }
?>