<?php
    require("./includes/config.php");
    
    // checks if user has reached page via GET
    if($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // presents form if so 
        render("unsubscribe_form.php");
    }
    // checks if user has reached page via POST
    else if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // sanitizes user input
        if(empty($_POST["password"]))
        {
            say("You must provide your password", "Sorry!");
        }
        else if(empty($_POST["phone"]))
        {
            say("You must provide your phone number", "Ooops!");
        }
        
        // looks for user in db
        $user = CS50::query("SELECT * FROM subscribers WHERE phonenumber = ?", $_POST["phone"]);
        
        // apologizes if phone number not found
        if(empty($user))
        {
            say("This phone number is not registered with out service", "Regrettably,");
        }
        
        // checks for correctness of password
        else if(password_verify($_POST["password"], $user[0]["password"]))
        {
            // deletes user if password correct
            CS50::query("DELETE FROM subscribers WHERE phonenumber = ?", $user[0]["phonenumber"]);
            say("you have been removed from our list :(", "Au revoir,"); 
        }
        else
        {
            // informs user of error otherwise
            say("Password is invalid", "Nice try");
        }
    }
?>