var = 1
while var == 1:
    import twitter_streaming
    
    
    