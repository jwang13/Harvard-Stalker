<?php
     require("./includes/config.php");
    
    // searches for celeb name in mysql database
    $rows = CS50::query("SELECT * FROM celebs WHERE name = ?", $argv[1]);
    
    // determines if celebrity has been found
    if($rows)
    {
        // sets celebrity as spotted
        CS50::query("UPDATE celebs SET spotted = 1 WHERE name = ?", $argv[1]);
        
        // notifies subscribers of detection via notify
        notify("{$argv[1]} has been detected on Harvard campus! Visit the URL https://ide50-esteller.c9.io/verify.php
        in order to confirm or deny this spotting!");
    }
?>