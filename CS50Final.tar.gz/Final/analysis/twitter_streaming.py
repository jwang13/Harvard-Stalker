#TO RUN:
# python twitter_streaming.py > twitter_data.txt
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()
# Import tweepy library
from tweepy import OAuthHandler
from tweepy import Stream
from tweepy.streaming import StreamListener
# outputs to twitter_data.txt
import sys 
sys.stdout = open('twitter_data.txt', 'w') 

# User credentials to access Twitter API 
access_token = "972617545-Vmmt4nyxkKuol72ZC0SeXYWcfQdhEGpH8pEAOJk4"
access_token_secret = "80Evj9iB4aTW6xNOL90MEmj5w9Zpu078OMDC2ACPe2m9T"
consumer_key = "rUgdVvlTLJwh8Bk16hSAh7ukj"
consumer_secret = "b7sIOdWyEzoLUgX0GABvK2FGVuNwLHR921swGZVHnKKEwkR2vr"


# Listener that just prints received tweets to stdout.
class StdOutListener(StreamListener):

    def on_data(self, data):
        # if 'boston' in data.text.lower():
        print data
        return True

    def on_error(self, status):
        print status


if __name__ == '__main__':

    # Twitter authentification & connects to Twitter Streaming API
    l = StdOutListener()
    auth = OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    stream = Stream(auth, l)


    # Celebrity keywords
    stream.filter( track=['harvard', 'boston', 'cambridge','lamont','widener','annenberg','mather','winthrop','pfoho','dunster'])
 