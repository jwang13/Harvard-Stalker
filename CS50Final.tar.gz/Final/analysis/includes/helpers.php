<?php

    /**
     * helpers.php
     *
     * Computer Science 50 Final Project-- Jenny Wang & Juan Esteller
     * Code from Problem Set 7 adapted to our own purposes
     *
     * Helper functions.
     */
    require("libphp-phpmailer/class.phpmailer.php");
    require_once("config.php");

    /**
     * Presents to user a message.
     */
    function say($message, $header)
    {
        render("message.php", ["message" => $message, "title" => $header]);
    }

    /**
     * Facilitates debugging by dumping contents of argument(s)
     * to browser.
     */
    function dump()
    {
        $arguments = func_get_args();
        require("../views/dump.php");
        exit;
    }
    
    /**
     * Redirects user to location, which can be a URL or
     * a relative path on the local host.
     *
     * http://stackoverflow.com/a/25643550/5156190
     *
     * Because this function outputs an HTTP header, it
     * must be called before caller outputs any HTML.
     */
    function redirect($location)
    {
        if (headers_sent($file, $line))
        {
            trigger_error("HTTP headers already sent at {$file}:{$line}", E_USER_ERROR);
        }
        header("Location: {$location}");
        exit;
    }

    /**
     * Renders view, passing in values.
     */
    function render($view, $values = [])
    {
        // if view exists, render it
        if (file_exists("./views/{$view}"))
        {
            
            require("./views/header.php");
            extract($values);
            require("./views/{$view}");
            require("./views/footer.php");
            exit;
        }

        // else err
        else
        {
            trigger_error("Invalid view: {$view}", E_USER_ERROR);
        }
    }
    
    /**
     * Sends an e-mail with a certain message to all subscribers.
     */
    function notify($message)
    {
        // extracs all users from database
        $users = CS50::query("SELECT * FROM subscribers");
        
        // sets up PHPmailer
        $mailer = new PHPMailer();
        $mailer ->IsSMTP();
        $mailer->Host = "smtp.gmail.com";
        
        // sets e-mail password
        $mailer->Password = "djm12345";
        $mailer->Port = 587;
        $mailer->SMTPAuth = true;
        $mailer->SMTPDebug = 1;
        $mailer->SMTPSecure = "tls";
        
        // sets e-mail username and sender
        $mailer->Username = "harvardcelebs@gmail.com";
        $mailer->SetFrom("harvardcelebs@gmail.com");
        
        // puts message input as argument in the e-mail. 
        $mailer->Body = $message;
        
        // iterates through users
        foreach($users as $user)
        {
            /** pushes user's number onto array of recipients with handle
             * corresponding to carrier */
            if($user["carrier"] == "att")
            {
                 $mailer->addAddress("{$user['phonenumber']}@txt.att.net");
             }
            else if($user["carrier"] == "sprint")
            {
                 $mailer->addAddress("{$user['phonenumber']}@messaging.sprintpcs.com");
             }
            else if($user["carrier"] == "verizon")
            {
                $mailer->addAddress("{$user['phonenumber']}@vtext.com");
            }
            else if($user["carrier"] == "tmobile")
            {
                $mailer->addAddress("{$user['phonenumber']}@tmomail.net");
            }
        }
        
        // sends the message
        $mailer->Send();
    }
?>
