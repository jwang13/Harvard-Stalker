Installation
============

Install from PyPI::

    easy_install tweepy

Install from source::

    git clone git://github.com/tweepy/tweepy.git
    cd tweepy
    python setup.py install

