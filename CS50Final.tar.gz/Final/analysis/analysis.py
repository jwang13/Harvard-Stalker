# parse and analyze the tweets
import json
import nltk
# import pandas as pd
# import matplotlib.pyplot as plt
tweets_data_path = 'twitter_data.txt'

tweets_data = []
tweets_file = open(tweets_data_path, "r")
for line in tweets_file:
    try:
        tweet = json.loads(line)
        tweets_data.append(tweet['text'])
    except:
        continue

from nltk.tag import pos_tag
import sys
import subprocess

celeb_names = []

for sentence in tweets_data:
    # print sentence
    boolean = 0
    if "#" in sentence:
        hashtag = sentence.split("#",1)[1] 
        hashtag.replace("#", "") #take case of case where there are several hashtags 40
        boolean = 1
    sentence = sentence.split("#", 1)[0]
    sentence.replace("#", "")
    parts = pos_tag(sentence.split())
    propernouns = [word for word,pos in parts if pos == 'NNP']
    # ['Michael','Jackson', 'McDonalds']
    # http://stackoverflow.com/questions/17669952/finding-proper-nouns-using-nltk-wordnet
    if "Harvard" in propernouns:
        propernouns.remove("Harvard")
    if "RT" in propernouns:
        propernouns.remove("RT")
    if "Omg" in propernouns:
        propernouns.remove("Omg")
    if "News):" in propernouns:
        propernouns.remove("News):")
    if "Widener" in propernouns:
        propernouns.remove("Widener")
    if "Annenberg" in propernouns:
        propernouns.remove("Annenberg")
    name = ' '.join(propernouns) 
    #print name
    celeb_names.append(name)
    if boolean == 1:
        if hashtag == name.replace(" ", ""):
            celeb_names.append(name)
# now we have an array, celeb_names, full of names
# print celeb_names
threshold = 3
import collections
duplicates =  [item for item, count in collections.Counter(celeb_names).items() if count > threshold]
# duplicates = set([x for x in celeb_names if celeb_names.count(x) > threshold]) #thresholding with 1
if '' in duplicates:
    duplicates.remove('')
# http://stackoverflow.com/questions/14047979/executing-python-script-in-php-and-exchanging-data-between-the-two
print duplicates 
if duplicates:
    for x in range(0, len(duplicates)):
        result = duplicates[x]
        result = result.replace("u'","")
        print result + '\n'
        output = subprocess.check_output(["php", 'search.php', result])
        #print json.dumps(result)
    
#could tweet notification as well here

