<?php
    // requires configuration
    require("./includes/config.php");
    CS50::query("UPDATE celebs SET spotted = 0, confirmed = 0" );
?>